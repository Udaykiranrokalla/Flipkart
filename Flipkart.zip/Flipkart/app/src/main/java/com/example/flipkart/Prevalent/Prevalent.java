package com.example.flipkart.Prevalent;

import com.example.flipkart.Model.Users;

public class Prevalent {
    public static Users currentOnlineUser;

    public static final String UserphoneKey = "Userphone";
    public static final String UserPasswordKey = "UserPassword";
}
